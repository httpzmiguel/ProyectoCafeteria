# POS Cafetería

Aplicación Java de consola y Swing para gestionar pedidos personalizables de una cafetería.
Ambas interfaces usan el núcleo compartido `com.cafeteria.service.CafeService`.

## Requisitos

- JDK 17 o superior
- Maven 3.9 o superior

## Compilar y ejecutar

### Forma más sencilla en Windows

Haz doble clic en alguno de estos archivos dentro de la carpeta del proyecto:

- `run-consola.bat`: abre el POS en la terminal.
- `run-gui.bat`: abre la ventana gráfica Swing.

También puedes abrir la carpeta del proyecto en VS Code, pulsar `F5` y seleccionar:

- `Ejecutar POS por consola`
- `Ejecutar POS con interfaz gráfica`

```powershell
mvn clean test
mvn compile
mvn exec:java -Dexec.mainClass=com.cafeteria.ui.CafeConsole
mvn exec:java -Dexec.mainClass=com.cafeteria.ui.CafeSwing
```

## Inicio de sesión

La interfaz gráfica solicita credenciales al abrirse:

- Administrador: `admin` / `admin123`
- Cajero: `cajero` / `cajero123`

El administrador puede crear, editar y eliminar productos. El cajero solo puede usar ventas,
crear pedidos y avanzar estados. La autorización se valida también en `CafeService`, no solo
en los botones de la interfaz.

Los productos creados y sus precios se guardan automáticamente en `data/cafeteria.xlsx`,
en la hoja `Productos`. El catálogo CSV existente se migra automáticamente al abrir la aplicación.
Los usuarios se almacenan en `data/usuarios.csv`; los pedidos y ventas permanecen en memoria
durante la ejecución actual.

## Interfaz gráfica

La interfaz usa FlatLaf con una paleta cálida personalizada, MigLayout para distribuir
componentes, iconos SVG incluidos localmente y JFreeChart para las estadísticas de pedidos,
ventas acumuladas y promedio por pedido.

## Funcionalidades implementadas

- Menú configurable y productos personalizables con adiciones.
- Constructor guiado de combos.
- Promociones intercambiables por porcentaje y Happy Hour.
- Estados de pedido y transiciones controladas.
- Avisos a Cocina, Caja y Mesero.
- Cierre de caja y total acumulado.
- Interfaces por consola y Swing sobre el mismo núcleo.
- Panel gráfico con indicadores y gráficos de ventas y estados de pedidos.
- Pruebas unitarias JUnit 5 para los patrones.

## Patrones utilizados

- **Builder**: creación flexible de combos (`Combo.Builder`).
- **Decorator**: adiciones que modifican descripción y precio (`AdditionDecorator`).
- **Strategy**: promociones de horario o porcentaje (`PromotionStrategy`).
- **Observer**: avisos simultáneos a estaciones al cambiar un pedido.
- **State**: flujo Pendiente -> Preparando -> Listo -> Entregado.

## Alcance excluido

Se excluyen persistencia en base de datos, pago electrónico, impresión física de facturas,
inventario y administración de cuentas de usuario. Los roles de administrador y cajero usan
cuentas locales de demostración para el alcance académico.
