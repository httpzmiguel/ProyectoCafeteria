@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot"
set "PATH=%JAVA_HOME%\bin;%PATH%"
set "MVN=C:\Tools\apache-maven-3.9.9\bin\mvn.cmd"

if not exist "%MVN%" (
    echo No se encontro Maven en %MVN%
    echo Instala Maven o abre el proyecto con VS Code.
    pause
    exit /b 1
)

"%MVN%" compile exec:java "-Dexec.mainClass=com.cafeteria.ui.CafeConsole"
pause
