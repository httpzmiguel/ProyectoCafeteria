package com.cafeteria;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import com.cafeteria.model.AdditionDecorator;
import com.cafeteria.model.MenuProduct;
import com.cafeteria.model.Product;

class AdditionDecoratorTest {
    @Test
    void addsNameAndPriceToBaseProduct() {
        Product base = new MenuProduct("Café", "Café", new BigDecimal("4500"));
        Product customized = new AdditionDecorator(base, "Leche", new BigDecimal("1200"));

        assertEquals(new BigDecimal("5700"), customized.getPrice());
        assertEquals("Café, Leche", customized.getDescription());
    }
}
