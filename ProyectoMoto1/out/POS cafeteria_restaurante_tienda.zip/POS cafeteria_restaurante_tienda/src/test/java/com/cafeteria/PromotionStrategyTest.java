package com.cafeteria;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import com.cafeteria.pattern.HappyHourPromotion;
import com.cafeteria.pattern.PercentagePromotion;

class PromotionStrategyTest {
    @Test
    void happyHourAppliesDuringWindow() {
        BigDecimal result = new HappyHourPromotion().apply(
                new BigDecimal("10000"), LocalDateTime.of(2026, 11, 18, 16, 0));
        assertEquals(new BigDecimal("8500.00"), result);
    }

    @Test
    void percentagePromotionIsReusable() {
        BigDecimal result = new PercentagePromotion("Estudiante", new BigDecimal("10")).apply(
                new BigDecimal("10000"), LocalDateTime.now());
        assertEquals(new BigDecimal("9000.00"), result);
    }
}
