package com.cafeteria;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import com.cafeteria.model.Combo;
import com.cafeteria.model.MenuProduct;

class ComboBuilderTest {
    @Test
    void buildsComboAndAppliesDiscount() {
        Combo combo = new Combo.Builder()
                .name("Desayuno")
                .with(new MenuProduct("Café", "Café", new BigDecimal("4500")))
                .with(new MenuProduct("Sandwich", "Sandwich", new BigDecimal("9000")))
                .discount(new BigDecimal("1000"))
                .build();

        assertEquals(new BigDecimal("12500"), combo.getPrice());
        assertEquals("Café + Sandwich", combo.getDescription());
    }

    @Test
    void rejectsComboWithoutName() {
        assertThrows(IllegalStateException.class, () -> new Combo.Builder().build());
    }
}
