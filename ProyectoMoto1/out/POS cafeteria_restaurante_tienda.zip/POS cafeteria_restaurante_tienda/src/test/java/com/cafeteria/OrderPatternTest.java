package com.cafeteria;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.cafeteria.model.Order;
import com.cafeteria.pattern.NotifierObserver;

class OrderPatternTest {
    @Test
    void stateAndObserversAdvanceTogether() {
        Order order = new Order(1);
        NotifierObserver kitchen = new NotifierObserver("Cocina");
        NotifierObserver cashier = new NotifierObserver("Caja");
        order.addObserver(kitchen);
        order.addObserver(cashier);

        order.advance();

        assertEquals("Preparando", order.getStateName());
        assertEquals(1, kitchen.getNotifications().size());
        assertEquals(1, cashier.getNotifications().size());
    }
}
