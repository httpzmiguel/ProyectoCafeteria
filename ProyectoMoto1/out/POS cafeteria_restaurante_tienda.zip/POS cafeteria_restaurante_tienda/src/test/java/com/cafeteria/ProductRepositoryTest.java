package com.cafeteria;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.cafeteria.model.MenuProduct;
import com.cafeteria.model.Product;
import com.cafeteria.persistence.ProductRepository;

class ProductRepositoryTest {
    @TempDir
    Path tempDir;

    @Test
    void savesAndReloadsProductsFromExcel() {
        Path workbook = tempDir.resolve("cafeteria.xlsx");
        ProductRepository repository = new ProductRepository(workbook);
        repository.save(List.of(new MenuProduct(
                "Latte vainilla", "Café; leche y vainilla", new BigDecimal("7350.50"))));

        List<Product> products = new ProductRepository(workbook).load();

        assertEquals(1, products.size());
        assertEquals("Latte vainilla", products.get(0).getName());
        assertEquals("Café; leche y vainilla", products.get(0).getDescription());
        assertEquals(0, new BigDecimal("7350.50").compareTo(products.get(0).getPrice()));
    }

    @Test
    void migratesExistingBase64CsvCatalogToExcel() throws Exception {
        Path legacy = tempDir.resolve("productos.csv");
        Path workbook = tempDir.resolve("cafeteria.xlsx");
        String row = encode("Mocaccino") + ";" + encode("Café con chocolate") + ";" + encode("8200");
        Files.write(legacy, row.getBytes(StandardCharsets.UTF_8));

        List<Product> products = new ProductRepository(workbook).load();

        assertTrue(Files.exists(workbook));
        assertEquals(1, products.size());
        assertEquals("Mocaccino", products.get(0).getName());
        assertEquals(0, new BigDecimal("8200").compareTo(products.get(0).getPrice()));
    }

    private String encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }
}
