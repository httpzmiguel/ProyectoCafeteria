package com.cafeteria;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import com.cafeteria.model.Session;
import com.cafeteria.model.UserRole;
import com.cafeteria.service.CafeService;

class AuthPermissionTest {
    @Test
    void cashierCannotEditProductPrices() {
        CafeService service = new CafeService();
        Session cashier = service.login("cajero", "cajero123");

        assertEquals(UserRole.CASHIER, cashier.getUser().getRole());
        assertThrows(SecurityException.class, () ->
                service.updateProduct(cashier, "Café americano", "Café americano",
                        "Café", new BigDecimal("5000")));
    }

    @Test
    void adminCanCreateProduct() {
        CafeService service = new CafeService();
        Session admin = service.login("admin", "admin123");
        String name = "Prueba temporal " + System.nanoTime();

        service.createProduct(admin, name, "Producto de prueba", new BigDecimal("1234"));

        assertTrue(service.getMenu().containsKey(name));
        service.deleteProduct(admin, name);
    }

    @Test
    void rejectsInvalidCredentials() {
        CafeService service = new CafeService();
        assertThrows(SecurityException.class, () -> service.login("nadie", "incorrecta"));
    }
}
