package com.cafeteria.model;

public class Session {
    private final User user;

    public Session(User user) {
        if (user == null) {
            throw new IllegalArgumentException("La sesión requiere un usuario");
        }
        this.user = user;
    }

    public User getUser() { return user; }
    public boolean isAdmin() { return user.getRole() == UserRole.ADMIN; }
    public boolean isCashier() { return user.getRole() == UserRole.CASHIER; }

    public void requireAdmin() {
        if (!isAdmin()) {
            throw new SecurityException("Esta operación solo está disponible para administradores");
        }
    }
}
