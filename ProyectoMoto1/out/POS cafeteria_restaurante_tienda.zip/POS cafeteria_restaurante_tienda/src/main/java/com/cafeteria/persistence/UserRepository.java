package com.cafeteria.persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.cafeteria.model.User;
import com.cafeteria.model.UserRole;

public class UserRepository {
    private final Path file;

    public UserRepository() {
        this(Paths.get("data", "usuarios.csv"));
    }

    public UserRepository(Path file) {
        this.file = file;
    }

    public Optional<User> authenticate(String username, String password) {
        List<User> users = load();
        return users.stream()
                .filter(u -> u.getUsername().equalsIgnoreCase(username.trim()))
                .filter(u -> u.getPassword().equals(password))
                .findFirst();
    }

    public List<User> load() {
        if (!Files.exists(file)) {
            List<User> defaults = new ArrayList<>();
            defaults.add(new User("admin", "admin123", UserRole.ADMIN));
            defaults.add(new User("cajero", "cajero123", UserRole.CASHIER));
            save(defaults);
            return defaults;
        }

        List<User> users = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(";", -1);
                if (parts.length != 3) continue;
                users.add(new User(parts[0].trim(), parts[1], UserRole.valueOf(parts[2].trim())));
            }
        } catch (IOException | IllegalArgumentException e) {
            throw new RepositoryException("No fue posible leer los usuarios", e);
        }
        return users;
    }

    public void save(List<User> users) {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                for (User user : users) {
                    writer.write(user.getUsername() + ";" + user.getPassword() + ";" + user.getRole().name());
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            throw new RepositoryException("No fue posible guardar los usuarios", e);
        }
    }
}
