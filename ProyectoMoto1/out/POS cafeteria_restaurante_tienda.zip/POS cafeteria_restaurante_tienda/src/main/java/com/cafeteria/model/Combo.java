package com.cafeteria.model;

import java.math.BigDecimal;

public class Combo implements Product {
    private final String name;
    private final String description;
    private final BigDecimal price;

    private Combo(Builder builder) {
        name = builder.name;
        description = builder.description;
        price = builder.price;
    }

    @Override public String getName() { return name; }
    @Override public String getDescription() { return description; }
    @Override public BigDecimal getPrice() { return price; }

    public static class Builder {
        private String name;
        private String description = "";
        private BigDecimal price = BigDecimal.ZERO;

        public Builder name(String name) { this.name = name; return this; }
        public Builder with(Product product) {
            description += (description.isEmpty() ? "" : " + ") + product.getName();
            price = price.add(product.getPrice());
            return this;
        }
        public Builder discount(BigDecimal amount) {
            price = price.subtract(amount).max(BigDecimal.ZERO);
            return this;
        }
        public Combo build() {
            if (name == null || name.trim().isEmpty()) {
                throw new IllegalStateException("El combo debe tener nombre");
            }
            return new Combo(this);
        }
    }
}
