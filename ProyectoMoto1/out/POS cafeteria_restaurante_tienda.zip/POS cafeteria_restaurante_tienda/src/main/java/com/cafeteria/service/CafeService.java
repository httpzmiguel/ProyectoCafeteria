package com.cafeteria.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.cafeteria.model.MenuProduct;
import com.cafeteria.model.Order;
import com.cafeteria.model.Product;
import com.cafeteria.pattern.NotifierObserver;
import com.cafeteria.pattern.NoPromotion;
import com.cafeteria.pattern.PromotionStrategy;
import com.cafeteria.model.Session;
import com.cafeteria.model.User;
import com.cafeteria.persistence.ProductRepository;
import com.cafeteria.persistence.UserRepository;

public class CafeService {
    private final Map<String, Product> menu = new LinkedHashMap<>();
    private final List<Order> orders = new ArrayList<>();
    private final NotifierObserver kitchen = new NotifierObserver("Cocina");
    private final NotifierObserver cashier = new NotifierObserver("Caja");
    private final NotifierObserver waiter = new NotifierObserver("Mesero");
    private PromotionStrategy promotion = new NoPromotion();
    private final ProductRepository productRepository = new ProductRepository();
    private final UserRepository userRepository = new UserRepository();

    public CafeService() {
        for (Product product : productRepository.load()) {
            addProduct(product);
        }
    }

    public Session login(String username, String password) {
        User user = userRepository.authenticate(username, password)
                .orElseThrow(() -> new SecurityException("Usuario o contraseña incorrectos"));
        return new Session(user);
    }

    public void addProduct(Product product) {
        menu.put(product.getName(), product);
    }

    public void createProduct(Session session, String name, String description, BigDecimal price) {
        session.requireAdmin();
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del producto es obligatorio");
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("El precio debe ser mayor o igual a cero");
        }
        MenuProduct product = new MenuProduct(name.trim(), description == null ? "" : description.trim(), price);
        menu.put(product.getName(), product);
        productRepository.save(new ArrayList<>(menu.values()));
    }

    public void updateProduct(Session session, String currentName, String name, String description, BigDecimal price) {
        session.requireAdmin();
        if (!menu.containsKey(currentName)) {
            throw new IllegalArgumentException("Producto no encontrado");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del producto es obligatorio");
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("El precio debe ser mayor o igual a cero");
        }
        MenuProduct product = new MenuProduct(name.trim(), description == null ? "" : description.trim(), price);
        menu.remove(currentName);
        menu.put(product.getName(), product);
        productRepository.save(new ArrayList<>(menu.values()));
    }

    public void deleteProduct(Session session, String name) {
        session.requireAdmin();
        if (menu.remove(name) == null) {
            throw new IllegalArgumentException("Producto no encontrado");
        }
        productRepository.save(new ArrayList<>(menu.values()));
    }

    public Map<String, Product> getMenu() {
        return Collections.unmodifiableMap(menu);
    }

    public void setPromotion(PromotionStrategy promotion) {
        this.promotion = promotion;
    }

    public PromotionStrategy getPromotion() {
        return promotion;
    }

    public Order createOrder(List<Product> items) {
        Order order = new Order(orders.size() + 1);
        items.forEach(order::addItem);
        order.addObserver(kitchen);
        order.addObserver(cashier);
        order.addObserver(waiter);
        orders.add(order);
        order.notifyObservers();
        return order;
    }

    public void advanceOrder(Order order) {
        order.advance();
    }

    public BigDecimal calculateTotal(Order order) {
        return promotion.apply(order.getSubtotal(), LocalDateTime.now());
    }

    public BigDecimal closeCashRegister() {
        return orders.stream()
                .filter(order -> !"Cancelado".equals(order.getStateName()))
                .map(this::calculateTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public List<Order> getOrders() {
        return Collections.unmodifiableList(orders);
    }

    public NotifierObserver getKitchen() { return kitchen; }
    public NotifierObserver getCashier() { return cashier; }
    public NotifierObserver getWaiter() { return waiter; }
}
