package com.cafeteria.pattern;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class PercentagePromotion implements PromotionStrategy {
    private final String name;
    private final BigDecimal percentage;

    public PercentagePromotion(String name, BigDecimal percentage) {
        this.name = name;
        this.percentage = percentage;
    }

    @Override public String getName() { return name; }
    @Override public BigDecimal apply(BigDecimal subtotal, LocalDateTime at) {
        BigDecimal factor = BigDecimal.ONE.subtract(percentage.divide(new BigDecimal("100")));
        return subtotal.multiply(factor).setScale(2, java.math.RoundingMode.HALF_UP);
    }
}
