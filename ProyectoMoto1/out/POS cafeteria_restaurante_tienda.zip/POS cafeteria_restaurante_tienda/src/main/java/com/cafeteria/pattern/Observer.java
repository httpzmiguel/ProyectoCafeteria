package com.cafeteria.pattern;

import com.cafeteria.model.Order;

public interface Observer {
    void update(Order order);
}
