package com.cafeteria.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import com.cafeteria.model.Order;
import com.cafeteria.model.Product;
import com.cafeteria.model.Session;
import com.cafeteria.service.CafeService;
import com.formdev.flatlaf.extras.FlatSVGIcon;
import net.miginfocom.swing.MigLayout;

public class CafeSwing extends JFrame {
    private static final NumberFormat CURRENCY = NumberFormat.getCurrencyInstance(new Locale("es", "CO"));

    private final CafeService service = new CafeService();
    private Session session;
    private JPanel productPanel;
    private JTabbedPane tabs;

    private final DefaultListModel<String> cartModel = new DefaultListModel<>();
    private final DefaultListModel<String> orderModel = new DefaultListModel<>();
    private final DefaultListModel<String> notificationModel = new DefaultListModel<>();
    private final List<Product> cart = new ArrayList<>();
    private final DefaultTableModel productTableModel =
            new DefaultTableModel(new Object[]{"Producto", "Descripción", "Precio"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
    private final JTable productTable = new JTable(productTableModel);
    private final DefaultCategoryDataset salesDataset = new DefaultCategoryDataset();
    private final DefaultCategoryDataset statesDataset = new DefaultCategoryDataset();

    private JLabel totalLabel;
    private JLabel sessionLabel;
    private JLabel ordersKpi;
    private JLabel revenueKpi;
    private JLabel averageKpi;

    public CafeSwing() {
        super("Café Central | Punto de venta");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(980, 680));
        setSize(1180, 780);
        setLocationRelativeTo(null);
        showLoginDialog();
    }

    private void showLoginDialog() {
        JDialog dialog = new JDialog(this, "Iniciar sesión", true);
        dialog.setSize(420, 330);
        dialog.setLocationRelativeTo(null);
        dialog.setLayout(new MigLayout("fill, insets 28 34 24 34, gap 0", "[grow]", "[][18!][][grow][]"));

        JLabel icon = new JLabel(new FlatSVGIcon("icons/coffee.svg", 38, 38));
        JLabel title = new JLabel("Bienvenido a Café Central");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 21f));
        JLabel subtitle = new JLabel("Ingresa con tu cuenta para continuar");
        subtitle.setForeground(CafeTheme.MUTED);

        JPanel brand = new JPanel(new MigLayout("insets 0, gap 12", "[][grow]", "[center]"));
        brand.add(icon);
        brand.add(title, "wrap");
        brand.add(subtitle, "skip 1");
        dialog.add(brand, "growx, wrap, gapbottom 20");

        JTextField username = new JTextField();
        JPasswordField password = new JPasswordField();
        JPanel fields = new JPanel(new MigLayout("fillx, insets 0, wrap 1, gap 7", "[grow]"));
        fields.add(new JLabel("Usuario"));
        fields.add(username, "h 40!");
        fields.add(new JLabel("Contraseña"), "gapbefore 7");
        fields.add(password, "h 40!");
        dialog.add(fields, "growx, wrap");

        JButton enter = primaryButton("Ingresar", new FlatSVGIcon("icons/orders.svg", 17, 17));
        enter.addActionListener(e -> {
            try {
                session = service.login(username.getText(), new String(password.getPassword()));
                dialog.dispose();
                buildInterface();
            } catch (SecurityException ex) {
                JOptionPane.showMessageDialog(dialog, ex.getMessage(), "Acceso denegado",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
        dialog.add(enter, "growx, h 42!, gaptop 18");
        dialog.getRootPane().setDefaultButton(enter);
        dialog.setVisible(true);

        if (session == null) {
            dispose();
            System.exit(0);
        }
    }

    private void buildInterface() {
        JPanel root = new JPanel(new MigLayout("fill, insets 0, gap 0", "[grow]", "[68!][grow]"));
        root.add(buildHeader(), "growx, wrap");

        tabs = new JTabbedPane();
        tabs.putClientProperty("JTabbedPane.leadingTabPosition", "top");
        tabs.addTab("  Ventas", new FlatSVGIcon("icons/cart.svg", 18, 18), buildSalesPanel());
        if (session.isAdmin()) {
            tabs.addTab("  Productos", new FlatSVGIcon("icons/coffee.svg", 18, 18), buildAdminPanel());
        }
        tabs.addTab("  Pedidos", new FlatSVGIcon("icons/orders.svg", 18, 18), buildOrdersPanel());
        tabs.addTab("  Estadísticas", new FlatSVGIcon("icons/chart.svg", 18, 18), buildStatsPanel());
        root.add(tabs, "grow");
        setContentPane(root);
        setVisible(true);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new MigLayout("fill, insets 14 24 12 24", "[grow][]", "[center]"));
        header.setBackground(CafeTheme.SURFACE);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, CafeTheme.BORDER));

        JLabel brand = new JLabel("Café Central");
        brand.setFont(brand.getFont().deriveFont(Font.BOLD, 21f));
        brand.setForeground(CafeTheme.PRIMARY_DARK);
        header.add(brand, "split 2");
        JLabel descriptor = new JLabel("PUNTO DE VENTA");
        descriptor.setFont(descriptor.getFont().deriveFont(Font.BOLD, 10f));
        descriptor.setForeground(CafeTheme.MUTED);
        header.add(descriptor);

        JPanel user = new JPanel(new MigLayout("insets 0, gap 10", "[][grow][]", "[center]"));
        user.setOpaque(false);
        JLabel avatar = new JLabel(session.isAdmin() ? "A" : "C", SwingConstants.CENTER);
        avatar.setOpaque(true);
        avatar.setForeground(Color.WHITE);
        avatar.setBackground(CafeTheme.PRIMARY);
        avatar.setFont(avatar.getFont().deriveFont(Font.BOLD, 14f));
        avatar.setPreferredSize(new Dimension(34, 34));
        user.add(avatar, "w 34!, h 34!");

        JPanel identity = new JPanel(new MigLayout("insets 0, gap 1, wrap 1", "[grow]"));
        identity.setOpaque(false);
        sessionLabel = new JLabel(session.getUser().getUsername());
        sessionLabel.setFont(sessionLabel.getFont().deriveFont(Font.BOLD));
        identity.add(sessionLabel);
        JLabel role = new JLabel(session.isAdmin() ? "Administrador" : "Cajero");
        role.setForeground(CafeTheme.MUTED);
        role.setFont(role.getFont().deriveFont(11f));
        identity.add(role);
        user.add(identity);

        JButton logout = secondaryButton("Salir");
        logout.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new CafeSwing());
        });
        user.add(logout);
        header.add(user, "right");
        return header;
    }

    private JPanel buildSalesPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 22, gap 18",
                "[grow][330!]", "[grow]"));

        JPanel menuContainer = new JPanel(new MigLayout("fill, insets 0, gap 12", "[grow]", "[][grow]"));
        JPanel title = sectionTitle("Registrar venta", "Selecciona productos para agregarlos al carrito");
        menuContainer.add(title, "growx, wrap");
        productPanel = new JPanel(new MigLayout("fillx, wrap 3, insets 2, gap 12",
                "[grow,fill][grow,fill][grow,fill]", "[]"));
        refreshProductButtons();
        menuContainer.add(new JScrollPane(productPanel), "grow, wrap");
        panel.add(menuContainer, "grow");

        JPanel cartPanel = surfacePanel(new MigLayout("fill, insets 18, gap 12",
                "[grow]", "[][grow][][44!]"));
        JPanel cartTitle = sectionTitle("Tu pedido", "Revisa los productos antes de cobrar");
        cartPanel.add(cartTitle, "growx, wrap");
        JList<String> cartList = new JList<>(cartModel);
        cartList.setFixedCellHeight(42);
        cartPanel.add(new JScrollPane(cartList), "grow, wrap");

        totalLabel = new JLabel(formatCurrency(BigDecimal.ZERO), SwingConstants.RIGHT);
        totalLabel.setForeground(CafeTheme.PRIMARY_DARK);
        totalLabel.setFont(totalLabel.getFont().deriveFont(Font.BOLD, 25f));
        cartPanel.add(totalLabel, "growx, wrap");

        JPanel actions = new JPanel(new MigLayout("fillx, insets 0, gap 8", "[grow][grow]", "[42!]"));
        actions.setOpaque(false);
        JButton remove = secondaryButton("Quitar");
        remove.addActionListener(e -> {
            int index = cartList.getSelectedIndex();
            if (index >= 0) {
                cart.remove(index);
                refreshCart();
            }
        });
        JButton clear = secondaryButton("Vaciar");
        clear.addActionListener(e -> {
            cart.clear();
            refreshCart();
        });
        actions.add(remove, "grow");
        actions.add(clear, "grow");
        cartPanel.add(actions, "growx, wrap");

        JButton create = primaryButton("Cobrar y crear pedido", new FlatSVGIcon("icons/cart.svg", 17, 17));
        create.addActionListener(e -> createOrder());
        cartPanel.add(create, "growx, h 46!");
        panel.add(cartPanel, "growy, width 330!");
        return panel;
    }

    private JPanel surfacePanel(MigLayout layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(CafeTheme.SURFACE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CafeTheme.BORDER),
                BorderFactory.createEmptyBorder(2, 2, 2, 2)));
        return panel;
    }

    private void refreshProductButtons() {
        if (productPanel == null) return;
        productPanel.removeAll();
        for (Product product : service.getMenu().values()) {
            JPanel card = new JPanel(new MigLayout("fillx, insets 14, gap 8, wrap 1", "[grow]"));
            card.setBackground(CafeTheme.SURFACE);
            card.setBorder(BorderFactory.createLineBorder(CafeTheme.BORDER));
            JLabel name = new JLabel(product.getName());
            name.setFont(name.getFont().deriveFont(Font.BOLD, 15f));
            JLabel description = new JLabel(product.getDescription());
            description.setForeground(CafeTheme.MUTED);
            description.setFont(description.getFont().deriveFont(12f));
            JLabel price = new JLabel(formatCurrency(product.getPrice()));
            price.setForeground(CafeTheme.PRIMARY);
            price.setFont(price.getFont().deriveFont(Font.BOLD, 17f));
            card.add(name, "growx");
            card.add(description, "growx");
            card.add(price, "growx");
            JButton add = primaryButton("Agregar", null);
            add.addActionListener(e -> {
                cart.add(product);
                refreshCart();
            });
            card.add(add, "growx, h 36!");
            productPanel.add(card, "growx");
        }
        productPanel.revalidate();
        productPanel.repaint();
    }

    private void refreshCart() {
        cartModel.clear();
        BigDecimal total = BigDecimal.ZERO;
        for (Product product : cart) {
            cartModel.addElement(product.getName() + "     " + formatCurrency(product.getPrice()));
            total = total.add(product.getPrice());
        }
        if (totalLabel != null) totalLabel.setText(formatCurrency(total));
    }

    private void createOrder() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Agrega al menos un producto al carrito.");
            return;
        }
        Order order = service.createOrder(new ArrayList<>(cart));
        cart.clear();
        refreshCart();
        refreshOrders();
        refreshNotifications();
        refreshStats();
        JOptionPane.showMessageDialog(this,
                "Pedido #" + order.getId() + " creado.\nTotal: " + formatCurrency(service.calculateTotal(order)));
    }

    private JPanel buildAdminPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 22, gap 14",
                "[grow]", "[][grow][]"));
        panel.add(sectionTitle("Catálogo de productos",
                "Administra nombres, descripciones y precios del menú"), "growx, wrap");
        styleTable(productTable);
        panel.add(new JScrollPane(productTable), "grow, wrap");

        JPanel actions = new JPanel(new MigLayout("insets 0, gap 8", "[][][]"));
        actions.setOpaque(false);
        JButton add = primaryButton("Nuevo producto", new FlatSVGIcon("icons/coffee.svg", 16, 16));
        JButton edit = secondaryButton("Editar seleccionado");
        JButton delete = secondaryButton("Eliminar seleccionado");
        add.addActionListener(e -> addProduct());
        edit.addActionListener(e -> editProduct());
        delete.addActionListener(e -> deleteProduct());
        actions.add(add, "h 40!");
        actions.add(edit, "h 40!");
        actions.add(delete, "h 40!");
        panel.add(actions, "growx");
        refreshProductTable();
        return panel;
    }

    private void styleTable(JTable table) {
        table.setFillsViewportHeight(true);
        table.setRowHeight(40);
        table.setShowVerticalLines(false);
        table.setGridColor(CafeTheme.BORDER);
        table.getTableHeader().setFont(table.getTableHeader().getFont().deriveFont(Font.BOLD));
        table.getTableHeader().setBackground(CafeTheme.SURFACE);
    }

    private void refreshProductTable() {
        productTableModel.setRowCount(0);
        for (Product product : service.getMenu().values()) {
            productTableModel.addRow(new Object[]{
                    product.getName(), product.getDescription(), formatCurrency(product.getPrice())
            });
        }
    }

    private void addProduct() {
        JPanel form = productForm(null);
        JTextField name = (JTextField) form.getClientProperty("name");
        JTextField description = (JTextField) form.getClientProperty("description");
        JTextField price = (JTextField) form.getClientProperty("price");
        if (JOptionPane.showConfirmDialog(this, form, "Nuevo producto",
                JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                service.createProduct(session, name.getText(), description.getText(),
                        new BigDecimal(price.getText().trim()));
                refreshProductTable();
                refreshProductButtons();
            } catch (RuntimeException ex) {
                showError(ex);
            }
        }
    }

    private void editProduct() {
        int row = productTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto para editar.");
            return;
        }
        String currentName = (String) productTableModel.getValueAt(row, 0);
        Product current = service.getMenu().get(currentName);
        JPanel form = productForm(current);
        JTextField name = (JTextField) form.getClientProperty("name");
        JTextField description = (JTextField) form.getClientProperty("description");
        JTextField price = (JTextField) form.getClientProperty("price");
        if (JOptionPane.showConfirmDialog(this, form, "Editar producto",
                JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                service.updateProduct(session, currentName, name.getText(),
                        description.getText(), new BigDecimal(price.getText().trim()));
                refreshProductTable();
                refreshProductButtons();
            } catch (RuntimeException ex) {
                showError(ex);
            }
        }
    }

    private void deleteProduct() {
        int row = productTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto para eliminar.");
            return;
        }
        String name = (String) productTableModel.getValueAt(row, 0);
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar " + name + "?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                service.deleteProduct(session, name);
                refreshProductTable();
                refreshProductButtons();
            } catch (RuntimeException ex) {
                showError(ex);
            }
        }
    }

    private JPanel productForm(Product product) {
        JPanel form = new JPanel(new MigLayout("fillx, wrap 2, insets 8, gap 10",
                "[110!][grow]", "[][38!][][38!][][38!]"));
        JTextField name = new JTextField(product == null ? "" : product.getName());
        JTextField description = new JTextField(product == null ? "" : product.getDescription());
        JTextField price = new JTextField(product == null ? "" : product.getPrice().toPlainString());
        form.add(new JLabel("Nombre"));
        form.add(name, "growx");
        form.add(new JLabel("Descripción"));
        form.add(description, "growx");
        form.add(new JLabel("Precio"));
        form.add(price, "growx");
        form.putClientProperty("name", name);
        form.putClientProperty("description", description);
        form.putClientProperty("price", price);
        return form;
    }

    private JPanel buildOrdersPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 22, gap 16",
                "[grow][330!]", "[grow][]"));
        JPanel orderCard = surfacePanel(new MigLayout("fill, insets 16, gap 10", "[grow]", "[][grow][]"));
        orderCard.add(sectionTitle("Pedidos", "Estado y total de cada venta"), "growx, wrap");
        JList<String> orderList = new JList<>(orderModel);
        orderList.setFixedCellHeight(42);
        orderCard.add(new JScrollPane(orderList), "grow, wrap");

        JPanel orderActions = new JPanel(new MigLayout("insets 0, gap 8", "[][grow]"));
        orderActions.setOpaque(false);
        JButton advance = primaryButton("Avanzar seleccionado", null);
        advance.addActionListener(e -> {
            int index = orderList.getSelectedIndex();
            if (index >= 0) {
                try {
                    service.advanceOrder(service.getOrders().get(index));
                    refreshOrders();
                    refreshNotifications();
                    refreshStats();
                } catch (RuntimeException ex) {
                    showError(ex);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un pedido.");
            }
        });
        JButton close = secondaryButton("Cierre de caja");
        close.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Ventas acumuladas: " + formatCurrency(service.closeCashRegister()),
                "Cierre de caja", JOptionPane.INFORMATION_MESSAGE));
        orderActions.add(advance, "h 40!");
        orderActions.add(close, "h 40!");
        orderCard.add(orderActions, "growx");
        panel.add(orderCard, "grow");

        JPanel notifications = surfacePanel(new MigLayout("fill, insets 16, gap 10", "[grow]", "[][grow]"));
        notifications.add(sectionTitle("Actividad", "Avisos de cocina"), "growx, wrap");
        JList<String> notificationList = new JList<>(notificationModel);
        notifications.add(new JScrollPane(notificationList), "grow");
        panel.add(notifications, "growy");
        refreshOrders();
        refreshNotifications();
        return panel;
    }

    private JPanel buildStatsPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 22, gap 16", "[grow]", "[][grow]"));
        JPanel kpis = new JPanel(new MigLayout("fillx, insets 0, gap 14",
                "[grow][grow][grow]", "[104!]"));
        kpis.setOpaque(false);
        ordersKpi = new JLabel("0");
        revenueKpi = new JLabel(formatCurrency(BigDecimal.ZERO));
        averageKpi = new JLabel(formatCurrency(BigDecimal.ZERO));
        kpis.add(kpiCard("Pedidos registrados", ordersKpi), "grow");
        kpis.add(kpiCard("Ventas acumuladas", revenueKpi), "grow");
        kpis.add(kpiCard("Promedio por pedido", averageKpi), "grow");
        panel.add(kpis, "growx, wrap");

        JPanel charts = new JPanel(new MigLayout("fill, insets 0, gap 16", "[grow][grow]", "[grow]"));
        charts.setOpaque(false);
        ChartPanel salesChart = new ChartPanel(createChart(
                "Ventas por pedido", "Pedido", "Total vendido", salesDataset, CafeTheme.PRIMARY));
        ChartPanel statesChart = new ChartPanel(createChart(
                "Pedidos por estado", "Estado", "Cantidad", statesDataset, CafeTheme.ACCENT));
        salesChart.setMouseWheelEnabled(true);
        statesChart.setMouseWheelEnabled(true);
        charts.add(chartCard(salesChart), "grow");
        charts.add(chartCard(statesChart), "grow");
        panel.add(charts, "grow");
        refreshStats();
        return panel;
    }

    private JPanel kpiCard(String title, JLabel value) {
        JPanel card = surfacePanel(new MigLayout("fill, insets 16, gap 8, wrap 1", "[grow]", "[][grow]"));
        JLabel heading = new JLabel(title);
        heading.setForeground(CafeTheme.MUTED);
        value.setFont(value.getFont().deriveFont(Font.BOLD, 23f));
        value.setForeground(CafeTheme.PRIMARY_DARK);
        card.add(heading, "growx");
        card.add(value, "growx");
        return card;
    }

    private JPanel chartCard(ChartPanel chart) {
        JPanel card = surfacePanel(new MigLayout("fill, insets 10", "[grow]", "[grow]"));
        card.add(chart, "grow");
        return card;
    }

    private JFreeChart createChart(String title, String category, String value,
            DefaultCategoryDataset dataset, Color barColor) {
        JFreeChart chart = ChartFactory.createBarChart(title, category, value, dataset,
                PlotOrientation.VERTICAL, false, true, false);
        chart.setBackgroundPaint(CafeTheme.SURFACE);
        chart.getTitle().setFont(chart.getTitle().getFont().deriveFont(Font.BOLD, 15f));
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(CafeTheme.SURFACE);
        plot.setOutlineVisible(false);
        plot.setRangeGridlinePaint(CafeTheme.BORDER);
        plot.getRenderer().setSeriesPaint(0, barColor);
        return chart;
    }

    private void refreshStats() {
        if (ordersKpi == null) return;
        List<Order> orders = service.getOrders();
        BigDecimal revenue = service.closeCashRegister();
        BigDecimal average = orders.isEmpty() ? BigDecimal.ZERO
                : revenue.divide(BigDecimal.valueOf(orders.size()), 2, java.math.RoundingMode.HALF_UP);
        ordersKpi.setText(String.valueOf(orders.size()));
        revenueKpi.setText(formatCurrency(revenue));
        averageKpi.setText(formatCurrency(average));

        salesDataset.clear();
        statesDataset.clear();
        for (Order order : orders) {
            salesDataset.addValue(service.calculateTotal(order), "Ventas",
                    "Pedido #" + order.getId());
        }
        String[] statuses = {"Pendiente", "Preparando", "Listo", "Entregado", "Cancelado"};
        for (String status : statuses) {
            long count = orders.stream().filter(order -> status.equals(order.getStateName())).count();
            statesDataset.addValue(count, "Pedidos", status);
        }
    }

    private void refreshOrders() {
        orderModel.clear();
        for (Order order : service.getOrders()) {
            orderModel.addElement("Pedido #" + order.getId() + "  |  " + order.getStateName()
                    + "  |  " + formatCurrency(service.calculateTotal(order)));
        }
    }

    private JPanel sectionTitle(String title, String subtitle) {
        JPanel header = new JPanel(new MigLayout("fillx, insets 0, gap 3, wrap 1", "[grow]"));
        header.setOpaque(false);
        JLabel heading = new JLabel(title);
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 20f));
        heading.setForeground(CafeTheme.TEXT);
        JLabel detail = new JLabel(subtitle);
        detail.setFont(detail.getFont().deriveFont(12f));
        detail.setForeground(CafeTheme.MUTED);
        header.add(heading, "growx");
        header.add(detail, "growx");
        return header;
    }

    private JButton primaryButton(String text, javax.swing.Icon icon) {
        JButton button = new JButton(text, icon);
        button.setBackground(CafeTheme.PRIMARY);
        button.setForeground(Color.WHITE);
        button.setFont(button.getFont().deriveFont(Font.BOLD));
        button.setFocusPainted(false);
        return button;
    }

    private JButton secondaryButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(CafeTheme.SURFACE);
        button.setForeground(CafeTheme.TEXT);
        return button;
    }

    private String formatCurrency(BigDecimal amount) {
        return CURRENCY.format(amount);
    }

    private void showError(RuntimeException error) {
        JOptionPane.showMessageDialog(this, error.getMessage(), "No se pudo completar la operación",
                JOptionPane.ERROR_MESSAGE);
    }

    private void refreshNotifications() {
        notificationModel.clear();
        for (String notification : service.getKitchen().getNotifications()) {
            notificationModel.addElement(notification);
        }
    }

    public static void main(String[] args) {
        CafeTheme.install();
        SwingUtilities.invokeLater(CafeSwing::new);
    }
}
