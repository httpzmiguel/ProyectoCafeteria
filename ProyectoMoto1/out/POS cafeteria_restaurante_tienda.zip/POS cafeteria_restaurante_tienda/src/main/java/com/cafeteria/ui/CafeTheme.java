package com.cafeteria.ui;

import java.awt.Color;
import java.awt.Font;

import javax.swing.UIManager;

import com.formdev.flatlaf.FlatLightLaf;

public final class CafeTheme {
    public static final Color BACKGROUND = new Color(248, 247, 244);
    public static final Color SURFACE = Color.WHITE;
    public static final Color PRIMARY = new Color(105, 66, 45);
    public static final Color PRIMARY_DARK = new Color(75, 45, 31);
    public static final Color ACCENT = new Color(202, 139, 83);
    public static final Color TEXT = new Color(45, 42, 39);
    public static final Color MUTED = new Color(128, 121, 113);
    public static final Color BORDER = new Color(232, 227, 221);
    public static final Color SUCCESS = new Color(55, 125, 91);

    private CafeTheme() {
    }

    public static void install() {
        FlatLightLaf.setup();
        UIManager.put("defaultFont", new Font("Segoe UI", Font.PLAIN, 14));
        UIManager.put("Component.arc", 12);
        UIManager.put("Button.arc", 12);
        UIManager.put("TextComponent.arc", 10);
        UIManager.put("Component.focusWidth", 1);
        UIManager.put("Button.background", SURFACE);
        UIManager.put("Button.foreground", TEXT);
        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("TabbedPane.selectedBackground", SURFACE);
        UIManager.put("Table.rowHeight", 38);
        UIManager.put("Table.showHorizontalLines", true);
        UIManager.put("Table.showVerticalLines", false);
        UIManager.put("Table.selectionBackground", new Color(241, 232, 222));
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("List.selectionBackground", new Color(241, 232, 222));
        UIManager.put("List.selectionForeground", TEXT);
    }
}
