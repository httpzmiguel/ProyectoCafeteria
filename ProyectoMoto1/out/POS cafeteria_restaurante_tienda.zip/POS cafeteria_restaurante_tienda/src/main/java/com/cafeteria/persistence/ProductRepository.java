package com.cafeteria.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cafeteria.model.MenuProduct;
import com.cafeteria.model.Product;

public class ProductRepository {
    private static final String SHEET_NAME = "Productos";
    private static final String[] HEADERS = {"Nombre", "Descripción", "Precio"};

    private final Path file;
    private final Path legacyFile;

    public ProductRepository() {
        this(Paths.get("data", "cafeteria.xlsx"));
    }

    public ProductRepository(Path file) {
        this.file = file;
        this.legacyFile = file.resolveSibling("productos.csv");
    }

    public List<Product> load() {
        if (Files.exists(file)) {
            return loadWorkbook();
        }
        if (Files.exists(legacyFile)) {
            List<Product> migrated = loadLegacyCsv();
            save(migrated);
            return migrated;
        }

        List<Product> defaults = defaultProducts();
        save(defaults);
        return defaults;
    }

    public void save(List<Product> products) {
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);

            try (XSSFWorkbook workbook = new XSSFWorkbook();
                    OutputStream output = Files.newOutputStream(file)) {
                Sheet sheet = workbook.createSheet(SHEET_NAME);
                Row header = sheet.createRow(0);
                for (int column = 0; column < HEADERS.length; column++) {
                    header.createCell(column).setCellValue(HEADERS[column]);
                }

                int rowIndex = 1;
                for (Product product : products) {
                    Row row = sheet.createRow(rowIndex++);
                    row.createCell(0).setCellValue(product.getName());
                    row.createCell(1).setCellValue(product.getDescription());
                    row.createCell(2).setCellValue(product.getPrice().doubleValue());
                }

                for (int column = 0; column < HEADERS.length; column++) {
                    sheet.autoSizeColumn(column);
                }
                sheet.createFreezePane(0, 1);
                workbook.write(output);
            }
        } catch (IOException | IllegalArgumentException e) {
            throw new RepositoryException("No fue posible guardar los productos en Excel", e);
        }
    }

    private List<Product> loadWorkbook() {
        List<Product> products = new ArrayList<>();
        try (InputStream input = Files.newInputStream(file);
                XSSFWorkbook workbook = new XSSFWorkbook(input)) {
            Sheet sheet = workbook.getSheet(SHEET_NAME);
            if (sheet == null) {
                throw new RepositoryException("El archivo Excel no contiene la hoja Productos", null);
            }

            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null || row.getCell(0) == null || row.getCell(2) == null) continue;

                String name = row.getCell(0).getStringCellValue().trim();
                if (name.isEmpty()) continue;
                String description = row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue();
                Cell priceCell = row.getCell(2);
                BigDecimal price = priceCell.getCellType() == org.apache.poi.ss.usermodel.CellType.NUMERIC
                        ? BigDecimal.valueOf(priceCell.getNumericCellValue())
                        : new BigDecimal(priceCell.getStringCellValue().trim());
                products.add(new MenuProduct(name, description, price));
            }
        } catch (IOException | IllegalArgumentException | IllegalStateException e) {
            throw new RepositoryException("No fue posible leer los productos del archivo Excel", e);
        }
        return products;
    }

    private List<Product> loadLegacyCsv() {
        List<Product> products = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(legacyFile, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(";", -1);
                if (parts.length != 3) {
                    throw new IllegalArgumentException("Fila inválida en productos.csv");
                }
                products.add(new MenuProduct(
                        decode(parts[0]), decode(parts[1]), new BigDecimal(decode(parts[2]))));
            }
        } catch (IOException | IllegalArgumentException e) {
            throw new RepositoryException("No fue posible migrar productos.csv a Excel", e);
        }
        return products;
    }

    private List<Product> defaultProducts() {
        List<Product> products = new ArrayList<>();
        products.add(new MenuProduct("Café americano", "Café", new BigDecimal("4500")));
        products.add(new MenuProduct("Capuchino", "Café con leche", new BigDecimal("6500")));
        products.add(new MenuProduct("Sandwich", "Sandwich tostado", new BigDecimal("9000")));
        products.add(new MenuProduct("Limonada", "Bebida fría", new BigDecimal("5500")));
        return products;
    }

    private String decode(String value) {
        return new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
    }
}
