package com.cafeteria.ui;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cafeteria.model.AdditionDecorator;
import com.cafeteria.model.Order;
import com.cafeteria.model.Product;
import com.cafeteria.pattern.HappyHourPromotion;
import com.cafeteria.service.CafeService;

public class CafeConsole {
    private final CafeService service;
    private final Scanner scanner = new Scanner(System.in);

    public CafeConsole(CafeService service) {
        this.service = service;
    }

    public void run() {
        boolean running = true;
        while (running) {
            System.out.println("\n=== POS Cafetería ===");
            System.out.println("1. Ver menú");
            System.out.println("2. Crear pedido");
            System.out.println("3. Avanzar pedido");
            System.out.println("4. Activar Happy Hour");
            System.out.println("5. Cerrar caja");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            String option = scanner.nextLine().trim();
            switch (option) {
                case "1": showMenu(); break;
                case "2": createOrder(); break;
                case "3": advanceOrder(); break;
                case "4": service.setPromotion(new HappyHourPromotion()); break;
                case "5": closeCash(); break;
                case "0": running = false; break;
                default: System.out.println("Opción inválida.");
            }
        }
    }

    private void showMenu() {
        service.getMenu().values().forEach(p ->
                System.out.println(p.getName() + " - " + p.getDescription() + " - $" + p.getPrice()));
    }

    private void createOrder() {
        showMenu();
        List<Product> items = new ArrayList<>();
        System.out.println("Escriba nombres separados por coma:");
        String names = scanner.nextLine();
        for (String name : names.split(",")) {
            Product product = service.getMenu().get(name.trim());
            if (product != null) {
                System.out.print("¿Agregar leche (+$1200) a " + product.getName() + "? (s/n): ");
                if ("s".equalsIgnoreCase(scanner.nextLine().trim())) {
                    product = new AdditionDecorator(product, "Leche extra", new BigDecimal("1200"));
                }
                items.add(product);
            }
        }
        if (items.isEmpty()) {
            System.out.println("Pedido vacío.");
            return;
        }
        Order order = service.createOrder(items);
        System.out.println("Pedido #" + order.getId() + " creado. Total: $" + service.calculateTotal(order));
    }

    private void advanceOrder() {
        if (service.getOrders().isEmpty()) {
            System.out.println("No hay pedidos.");
            return;
        }
        System.out.print("Número de pedido: ");
        try {
            int id = Integer.parseInt(scanner.nextLine().trim());
            Order order = service.getOrders().stream()
                    .filter(o -> o.getId() == id).findFirst().orElse(null);
            if (order == null) {
                System.out.println("Pedido no encontrado.");
            } else {
                service.advanceOrder(order);
                System.out.println("Estado: " + order.getStateName());
                System.out.println("Última notificación cocina: " +
                        last(service.getKitchen().getNotifications()));
            }
        } catch (NumberFormatException e) {
            System.out.println("Número inválido.");
        }
    }

    private void closeCash() {
        System.out.println("Ventas acumuladas: $" + service.closeCashRegister());
    }

    private String last(List<String> values) {
        return values.isEmpty() ? "(sin notificaciones)" : values.get(values.size() - 1);
    }

    public static void main(String[] args) {
        new CafeConsole(new CafeService()).run();
    }
}
