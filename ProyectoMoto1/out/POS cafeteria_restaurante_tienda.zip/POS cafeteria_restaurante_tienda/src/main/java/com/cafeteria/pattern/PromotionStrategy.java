package com.cafeteria.pattern;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public interface PromotionStrategy {
    String getName();
    BigDecimal apply(BigDecimal subtotal, LocalDateTime at);
}
