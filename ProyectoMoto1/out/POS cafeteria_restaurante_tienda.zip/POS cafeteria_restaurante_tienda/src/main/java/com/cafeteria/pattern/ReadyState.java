package com.cafeteria.pattern;

public class ReadyState implements OrderState {
    @Override public String getName() { return "Listo"; }
    @Override public OrderState next() { return new DeliveredState(); }
}
