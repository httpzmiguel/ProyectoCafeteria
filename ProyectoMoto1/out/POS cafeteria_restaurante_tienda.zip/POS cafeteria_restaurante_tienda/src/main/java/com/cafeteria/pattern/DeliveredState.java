package com.cafeteria.pattern;

public class DeliveredState implements OrderState {
    @Override public String getName() { return "Entregado"; }
    @Override public OrderState next() { return this; }
}
