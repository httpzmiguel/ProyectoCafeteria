package com.cafeteria.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.cafeteria.pattern.Observer;
import com.cafeteria.pattern.OrderState;

public class Order implements com.cafeteria.pattern.OrderSubject {
    private final int id;
    private final LocalDateTime createdAt;
    private final List<Product> items = new ArrayList<>();
    private final List<Observer> observers = new ArrayList<>();
    private OrderState state = new com.cafeteria.pattern.PendingState();

    public Order(int id) {
        this(id, LocalDateTime.now());
    }

    public Order(int id, LocalDateTime createdAt) {
        this.id = id;
        this.createdAt = createdAt;
    }

    public void addItem(Product product) {
        items.add(product);
    }

    public List<Product> getItems() {
        return Collections.unmodifiableList(items);
    }

    public int getId() { return id; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public String getStateName() { return state.getName(); }

    public BigDecimal getSubtotal() {
        return items.stream()
                .map(Product::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void advance() {
        state = state.next();
        notifyObservers();
    }

    public void cancel() {
        state = new com.cafeteria.pattern.CancelledState();
        notifyObservers();
    }

    @Override public void addObserver(Observer observer) { observers.add(observer); }
    @Override public void removeObserver(Observer observer) { observers.remove(observer); }
    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }
}
