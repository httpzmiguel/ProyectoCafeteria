package com.cafeteria.pattern;

public interface OrderSubject {
    void addObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
}
