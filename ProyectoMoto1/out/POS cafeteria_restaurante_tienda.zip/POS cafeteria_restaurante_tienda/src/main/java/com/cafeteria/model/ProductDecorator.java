package com.cafeteria.model;

import java.math.BigDecimal;

public abstract class ProductDecorator implements Product {
    protected final Product wrapped;

    protected ProductDecorator(Product wrapped) {
        this.wrapped = wrapped;
    }

    @Override public String getName() { return wrapped.getName(); }
    @Override public String getDescription() { return wrapped.getDescription(); }
    @Override public BigDecimal getPrice() { return wrapped.getPrice(); }
}
