package com.cafeteria.pattern;

public class PendingState implements OrderState {
    @Override public String getName() { return "Pendiente"; }
    @Override public OrderState next() { return new PreparingState(); }
}
