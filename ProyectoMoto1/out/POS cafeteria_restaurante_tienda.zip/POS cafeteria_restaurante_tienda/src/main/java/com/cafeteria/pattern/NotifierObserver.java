package com.cafeteria.pattern;

import java.util.ArrayList;
import java.util.List;

import com.cafeteria.model.Order;

public class NotifierObserver implements Observer {
    private final String station;
    private final List<String> notifications = new ArrayList<>();

    public NotifierObserver(String station) {
        this.station = station;
    }

    @Override
    public void update(Order order) {
        notifications.add(station + ": pedido #" + order.getId() + " -> " + order.getStateName());
    }

    public List<String> getNotifications() {
        return new ArrayList<>(notifications);
    }
}
