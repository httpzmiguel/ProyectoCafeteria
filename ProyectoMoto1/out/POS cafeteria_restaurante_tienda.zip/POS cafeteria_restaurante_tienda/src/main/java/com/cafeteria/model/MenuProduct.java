package com.cafeteria.model;

import java.math.BigDecimal;

public class MenuProduct implements Product {
    private final String name;
    private final String description;
    private final BigDecimal price;

    public MenuProduct(String name, String description, BigDecimal price) {
        this.name = name;
        this.description = description;
        this.price = price;
    }

    @Override public String getName() { return name; }
    @Override public String getDescription() { return description; }
    @Override public BigDecimal getPrice() { return price; }
}
