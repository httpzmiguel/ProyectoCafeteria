package com.cafeteria.model;

public enum UserRole {
    ADMIN,
    CASHIER
}
