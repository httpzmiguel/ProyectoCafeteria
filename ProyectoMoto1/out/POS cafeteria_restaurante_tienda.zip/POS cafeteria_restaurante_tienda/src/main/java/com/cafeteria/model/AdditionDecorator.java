package com.cafeteria.model;

import java.math.BigDecimal;

public class AdditionDecorator extends ProductDecorator {
    private final String additionName;
    private final BigDecimal additionPrice;

    public AdditionDecorator(Product wrapped, String additionName, BigDecimal additionPrice) {
        super(wrapped);
        this.additionName = additionName;
        this.additionPrice = additionPrice;
    }

    @Override
    public String getDescription() {
        return wrapped.getDescription() + ", " + additionName;
    }

    @Override
    public BigDecimal getPrice() {
        return wrapped.getPrice().add(additionPrice);
    }
}
