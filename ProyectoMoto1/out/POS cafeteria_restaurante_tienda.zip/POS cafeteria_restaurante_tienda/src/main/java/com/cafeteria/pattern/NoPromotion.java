package com.cafeteria.pattern;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class NoPromotion implements PromotionStrategy {
    @Override public String getName() { return "Sin promoción"; }
    @Override public BigDecimal apply(BigDecimal subtotal, LocalDateTime at) { return subtotal; }
}
