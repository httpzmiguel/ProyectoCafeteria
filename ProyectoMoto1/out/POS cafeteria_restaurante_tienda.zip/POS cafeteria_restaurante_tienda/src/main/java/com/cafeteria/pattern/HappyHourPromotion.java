package com.cafeteria.pattern;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class HappyHourPromotion implements PromotionStrategy {
    @Override public String getName() { return "Happy Hour (15%)"; }
    @Override public BigDecimal apply(BigDecimal subtotal, LocalDateTime at) {
        int hour = at.getHour();
        if (hour >= 15 && hour < 17) {
            return subtotal.multiply(new BigDecimal("0.85")).setScale(2, java.math.RoundingMode.HALF_UP);
        }
        return subtotal;
    }
}
