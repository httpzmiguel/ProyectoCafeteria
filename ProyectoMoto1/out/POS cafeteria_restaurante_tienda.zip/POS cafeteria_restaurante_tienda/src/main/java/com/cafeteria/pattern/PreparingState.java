package com.cafeteria.pattern;

public class PreparingState implements OrderState {
    @Override public String getName() { return "Preparando"; }
    @Override public OrderState next() { return new ReadyState(); }
}
