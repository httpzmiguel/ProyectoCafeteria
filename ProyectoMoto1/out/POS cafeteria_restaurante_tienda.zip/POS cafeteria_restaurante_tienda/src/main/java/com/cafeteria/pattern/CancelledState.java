package com.cafeteria.pattern;

public class CancelledState implements OrderState {
    @Override public String getName() { return "Cancelado"; }
    @Override public OrderState next() { return this; }
}
