package com.cafeteria.pattern;

import com.cafeteria.model.Order;

public interface OrderState {
    String getName();
    OrderState next();
}
