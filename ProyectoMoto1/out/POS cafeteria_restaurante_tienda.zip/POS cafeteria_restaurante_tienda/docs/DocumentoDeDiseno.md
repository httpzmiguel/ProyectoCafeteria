# Documento de diseño

## Alcance y requisitos

### Funcionales
- RF-01: mostrar un menú configurable.
- RF-02: crear pedidos con productos individuales y adiciones.
- RF-03: crear combos a partir de varios productos.
- RF-04: aplicar promociones por horario o porcentaje.
- RF-05: cambiar estados de pedido siguiendo reglas válidas.
- RF-06: notificar a Cocina, Caja y Mesero al crear o avanzar pedidos.
- RF-07: calcular totales y cerrar caja.
- RF-08: operar desde consola y desde una interfaz Swing.

### No funcionales
- RNF-01: opciones claras y fáciles de usar.
- RNF-02: respuestas locales inmediatas en operaciones básicas.
- RNF-03: código separado en paquetes y clases con responsabilidad única.
- RNF-04: agregar productos, adiciones, combos y promociones sin modificar el flujo principal.
- RNF-05: ambas interfaces comparten `CafeService`.

## Problemas y patrones

### 1. Productos personalizados
**Problema:** tener un constructor por cada combinación (café con leche, café con leche y chocolate).
**Patrón:** Decorator.
**Roles reales:** `Product`, `MenuProduct`, `ProductDecorator` y `AdditionDecorator`.
**Alternativa descartada:** muchas subclases como `CafeConLeche`, `CafeConChocolate`; crecerían exponencialmente.
**Consecuencias:** permite encadenar adiciones, pero puede complicar la inspección de objetos decorados.
**SOLID:** abre la creación de adiciones a extensión sin modificar productos existentes (OCP) y mantiene
una misma abstracción (LSP).

### 2. Promociones variables
**Problema:** elegir entre promociones por horario, porcentaje o sin promoción sin usar muchos `if`.
**Patrón:** Strategy.
**Roles reales:** `PromotionStrategy`, `NoPromotion`, `PercentagePromotion` y `HappyHourPromotion`.
**Alternativa descartada:** una clase con banderas y condiciones por promoción.
**Consecuencias:** agregar una promoción es crear una clase nueva; el `CafeService` no conoce sus reglas.
**SOLID:** OCP e ISP por una interfaz pequeña; DIP porque el servicio depende de la interfaz.

### 3. Cambio de estado de pedidos
**Problema:** permitir transiciones inválidas o duplicar reglas en el método `actualizarEstado`.
**Patrón:** State.
**Roles reales:** `OrderState`, `PendingState`, `PreparingState`, `ReadyState`, `DeliveredState` y
`CancelledState`.
**Alternativa descartada:** una sola cadena de `if` sobre el nombre del estado.
**Consecuencias:** las reglas quedan distribuidas y el cambio es explícito.
**SOLID:** SRP y OCP para nuevas reglas o estados.

### 4. Avisos a varias áreas
**Problema:** notificar a Cocina, Caja y Mesero sin acoplar `Order` a cada estación.
**Patrón:** Observer.
**Roles reales:** `OrderSubject`, `Observer`, `NotifierObserver` y `Order`.
**Alternativa descartada:** llamar directamente a tres métodos en `advance()`.
**Consecuencias:** las estaciones pueden agregarse o quitarse; se ejecutan en secuencia.
**SOLID:** DIP y OCP; `Order` no depende de clases concretas.

### 5. Combos configurables
**Problema:** construir combos paso a paso con nombre, componentes y descuentos opcionales.
**Patrón:** Builder.
**Roles reales:** `Combo.Builder` y `Combo`.
**Alternativa descartada:** múltiples constructores y parámetros opcionales.
**Consecuencias:** la creación queda legible y valida el nombre obligatorio.
**SOLID:** SRP, constructor complejo separado del objeto producido.

## Arquitectura

La capa `model` representa el dominio, `pattern` contiene las abstracciones y estrategias reutilizables,
`service` reúne casos de uso y `ui` contiene consola y Swing. Las dos interfaces dependen de
`CafeService` y no contienen reglas de precio, estado o notificación.

## Cambio solicitado en vivo

Ejemplo: agregar `TaxDecorator`, una promoción `EstudiantePromotion` o un estado `Empacado`.
El núcleo permite el cambio sin modificar las interfaces: Decorator y Strategy reciben una clase nueva;
State requiere agregar una implementación que determine su siguiente estado.
